This is a simple future tense identification library.
This takes input as string or pandas dataframe.
This returns output as pandas dataframe.